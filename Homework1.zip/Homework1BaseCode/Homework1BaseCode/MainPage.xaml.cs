﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Globalization; // Provides access to Globalization settings APIs
using Windows.System.UserProfile; // Provides access to user preference setting APIs

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Homework1BaseCode
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();

            string geoSetting = System.Globalization.RegionInfo.CurrentRegion.DisplayName;
            string marketId = System.Globalization.RegionInfo.CurrentRegion.TwoLetterISORegionName;
            string currencySym = System.Globalization.RegionInfo.CurrentRegion.CurrencySymbol;
            string calendarSetting = GlobalizationPreferences.Calendars[0];
            string clockSetting = GlobalizationPreferences.Clocks.FirstOrDefault();
            string langSetting = GlobalizationPreferences.Languages.First();
            string topUserLanguage = GlobalizationPreferences.Languages[0];
            var toplanguage = new Language(topUserLanguage);
            string displayTopName = toplanguage.DisplayName;
            System.DayOfWeek firstDaySetting = System.Globalization.CultureInfo.CurrentUICulture.DateTimeFormat.FirstDayOfWeek;

            //Globalization Preferences
            calendar_setting.Text += "Calendar System: " + calendarSetting + "\n";
            clock_setting.Text += "Time Format: " + clockSetting + "\n";
            week_start.Text += "First Day of Week: " + firstDaySetting + "\n";
            chosen_lang.Text += "Language Setting: " + langSetting + "\n";
            home_region.Text += "Geographic Region: " + geoSetting + "\n";

            //Language Specifics
            lang_details.Text = "User's Top Language: " + displayTopName + "\n";

            //Geo Region Specifics
            geo_details.Text = "Geographic Region: " + geoSetting + "\n";
        }
    }
}